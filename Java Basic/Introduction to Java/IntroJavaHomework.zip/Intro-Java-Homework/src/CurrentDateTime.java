import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class CurrentDateTime {
	public static void main(String [] args){
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		//get current date time with Date()
		Date date = new Date();
		System.out.println(dateFormat.format(date));
	}
}
