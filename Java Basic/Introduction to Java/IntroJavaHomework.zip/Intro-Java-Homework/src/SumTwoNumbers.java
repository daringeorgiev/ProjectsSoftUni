import java.util.Scanner;

public class SumTwoNumbers {
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in); 
		System.out.print("Enter number 1: "); 
		int number1 = input.nextInt();
		System.out.print("Enter number 2: "); 
		int number2 = input.nextInt();
		//Print and sum
		System.out.print("Sum is: ");
		System.out.println(number1+number2);
	
	}
}
