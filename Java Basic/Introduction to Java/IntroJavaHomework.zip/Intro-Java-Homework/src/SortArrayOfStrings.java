import java.util.Scanner;
import java.util.Arrays;


public class SortArrayOfStrings {

	public static void main(String[] args) {
		// Set n
		Scanner input = new Scanner(System.in); 
		System.out.print("Enter n: "); 
		int n = input.nextInt();
		
		//Set strings
		String[] names = new String[n];
		for (int i = 0; i < names.length; i++) {
			System.out.print("Enter element: ");
			names[i]=input.next();
		}
		
		//Sort
		Arrays.sort(names);
		
		//Print
		for (int i = 0; i < names.length; i++) {
			System.out.println(names[i]);
		}
		
	}

}
