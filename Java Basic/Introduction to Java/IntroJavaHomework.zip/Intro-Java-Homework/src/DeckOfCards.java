import java.util.Scanner;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
 
import java.io.FileOutputStream;



public class DeckOfCards {

	public static void main(String[] args) {
//		 TODO Auto-generated method stub
//		Document document = new Document();
//        PdfWriter.getInstance(document, new FileOutputStream("MyFirstFile.pdf"));  
//        document.open();
//        
//        PdfPTable table = new PdfPTable(4);
//	    table.setWidthPercentage(100);
//	    table.getDefaultCell().setFixedHeight(180);
//		
//		String[] color={"♠", "♥", "♦", "♣"};	
//		for (int i = 0; i < 4; i++) {
//			for (int j = 2; j < 11; j++) {
//				System.out.print(j + color[i] + " ");
//			}
//			//Not numbers
//			System.out.print("J" + color[i] + " ");
//			System.out.print("Q" + color[i] + " ");
//			System.out.print("K" + color[i] + " ");
//			System.out.print("A" + color[i] + " ");
//			System.out.println();
//		}
//		 document.close();   
		

}
